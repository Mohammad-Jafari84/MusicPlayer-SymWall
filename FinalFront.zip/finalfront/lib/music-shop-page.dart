import 'package:flutter/material.dart';
import 'theme.dart';
import 'userProfile.dart';
import 'paymentPage.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'package:flutter/services.dart';
import 'dart:ui';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class ShopSong {
  final String id;
  final String title;
  final String artist;
  final String imagePath;
  final double rating;
  final double price;
  final int downloads;
  final bool isFree;

  ShopSong({
    required this.id,
    required this.title,
    required this.artist,
    required this.imagePath,
    required this.rating,
    required this.price,
    required this.downloads,
    required this.isFree,
  });
}

class Comment {
  final String id;
  final String username;
  final String text;
  final DateTime date;
  int likes;
  int dislikes;

  Comment({
    required this.id,
    required this.username,
    required this.text,
    required this.date,
    this.likes = 0,
    this.dislikes = 0,
  });
}

class MusicShopPage extends StatefulWidget {
  const MusicShopPage({Key? key}) : super(key: key);

  @override
  State<MusicShopPage> createState() => _MusicShopPageState();
}

enum SortOption { price, downloads, rating }

class _MusicShopPageState extends State<MusicShopPage> {
  bool _isPremium = false;
  bool _showAdCard = true; // Add this line at the top of the class

  final List<String> categories = [
    'Iranian',
    'Foreigner',
    'Top of songs',
    'The latest',
    'Local Assets', // دسته جدید برای آهنگ‌های asset
  ];

  String selectedCategory = 'Iranian';
  SortOption? selectedSortOption;

  final Map<String, List<ShopSong>> songsByCategory = {
    'Iranian': [
      ShopSong(
        id: '1',
        title: 'Ahoo',
        artist: 'Meysam Ebrahimi',
        imagePath:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRHz22XYGXnnynqPYzO8bJNjjgork8r0MXxwg&s',
        rating: 4.5,
        price: 1.99,
        downloads: 1000,
        isFree: false,
      ),
      ShopSong(
        id: '2',
        title: 'Divar',
        artist: 'Mehdi Ahmadvand',
        imagePath:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR6dwCkXdmRzoqZ_JzXVRf7HTtQK97iaGIROQ&s',
        rating: 4.2,
        price: 0.00,
        downloads: 2500,
        isFree: true,
      ),
      // اضافه کردن آهنگ ایرانی asset
      ShopSong(
        id: '3',
        title: 'Bi Ehsas',
        artist: 'Shadmehr Aghili',
        imagePath: 'assets/images/shadmehr-aghili-bi-ehsas.jpg',
        rating: 4.7,
        price: 0.00,
        downloads: 3000,
        isFree: true,
      ),
    ],
    'Foreigner': [
      ShopSong(
        id: '4',
        title: 'Shape of You',
        artist: 'Ed Sheeran',
        imagePath:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQkBcHnkbQmOIp93z5vk9ihLtzPTml2FOGMcg&s',
        rating: 4.8,
        price: 2.99,
        downloads: 5000,
        isFree: false,
      ),
      // اضافه کردن آهنگ خارجی asset
      ShopSong(
        id: '5',
        title: 'CLOUDS',
        artist: 'NF',
        imagePath: 'assets/images/Nf clouds.webp',
        rating: 4.9,
        price: 4.99,
        downloads: 8000,
        isFree: false,
      ),
    ],
    'Top of songs': [
      ShopSong(
        id: '6',
        title: 'Goriz',
        artist: 'Eb',
        imagePath:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQy4Q8Tr5CQI4BEnOzCI6cUbly2x6u7DkBojA&s',
        rating: 4.3,
        price: 0.99,
        downloads: 1200,
        isFree: false,
      ),
    ],
    'The latest': [
      ShopSong(
        id: '7',
        title: 'After You',
        artist: 'Mohsen Chavoshi',
        imagePath:
        'https://rozmusic.com/wp-content/uploads/2025/05/Mohsen-Chavoshi-Bad-Az-To.jpg',
        rating: 4.7,
        price: 1.49,
        downloads: 2000,
        isFree: false,
      ),
    ],
    'Local Assets': [], // آهنگ‌های asset اینجا اضافه می‌شوند
  };

  @override
  void initState() {
    super.initState();
    _loadPremiumStatus();
    _loadLocalAssetSongs(); // فراخوانی تابع جدید
  }

  // تابع جدید برای خواندن لیست آهنگ‌های asset
  Future<void> _loadLocalAssetSongs() async {
    try {
      // AssetManifest را بخوان و فقط mp3های assets/audio را پیدا کن
      final manifestContent = await rootBundle.loadString('AssetManifest.json');
      final Map<String, dynamic> manifestMap = json.decode(manifestContent);

      final audioFiles = manifestMap.keys
          .where((String key) =>
              key.startsWith('assets/audio/') && key.endsWith('.mp3'))
          .toList();

      final List<ShopSong> assetSongs = [];
      int idCounter = 100;

      for (final filePath in audioFiles) {
        final fileName = filePath.split('/').last;
        final title = fileName.replaceAll('.mp3', '').replaceAll('_', ' ');
        assetSongs.add(
          ShopSong(
            id: 'asset_$idCounter',
            title: title,
            artist: 'Local Artist',
            imagePath: 'assets/images/default_music.png',
            rating: 4.0,
            price: 0.0,
            downloads: 0,
            isFree: true,
          ),
        );
        idCounter++;
      }

      setState(() {
        songsByCategory['Local Assets'] = assetSongs;
      });
    } catch (e) {
      print('Error loading asset songs: $e');
      setState(() {
        songsByCategory['Local Assets'] = [];
      });
    }
  }

  Future<void> _loadPremiumStatus() async {
    final prefs = await SharedPreferences.getInstance();
    final subscription = prefs.getString('subscription') ?? 'STANDARD';
    setState(() {
      _isPremium = subscription.startsWith('PREMIUM');
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    final tt = theme.textTheme;

    final currentSongs = List<ShopSong>.from(
      songsByCategory[selectedCategory] ?? [],
    );
    if (selectedSortOption != null) {
      currentSongs.sort((a, b) {
        switch (selectedSortOption!) {
          case SortOption.price:
            return a.price.compareTo(b.price);
          case SortOption.downloads:
            return b.downloads.compareTo(a.downloads);
          case SortOption.rating:
            return b.rating.compareTo(a.rating);
        }
      });
    }

    return Scaffold(
      appBar: AppBar(
        backgroundColor: cs.surface,
        title: ShaderMask(
          shaderCallback: (bounds) => LinearGradient(
            colors: [cs.primary, cs.secondary],
          ).createShader(bounds),
          child: Text(
            'Music Shop',
            style: tt.titleLarge?.copyWith(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.2,
            ),
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.person, color: cs.primary),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => UserProfile()),
              );
            },
          ),
          PopupMenuButton<SortOption>(
            icon: Icon(Icons.sort, color: cs.primary),
            onSelected: (opt) => setState(() => selectedSortOption = opt),
            itemBuilder: (_) => [
              PopupMenuItem(
                value: SortOption.price,
                child: Text('Sort by Price', style: tt.bodyMedium),
              ),
              PopupMenuItem(
                value: SortOption.downloads,
                child: Text('Sort by Downloads', style: tt.bodyMedium),
              ),
              PopupMenuItem(
                value: SortOption.rating,
                child: Text('Sort by Rating', style: tt.bodyMedium),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Add advertisement card at the top
          if (_showAdCard)
            Padding(
              padding: const EdgeInsets.all(16),
              child: Stack(
                children: [
                  Container(
                    height: 180,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: cs.primary.withOpacity(0.2),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: Image.asset(
                        'assets/images/Nf clouds.webp',
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  Positioned(
                    top: 8,
                    right: 8,
                    child: InkWell(
                      onTap: () => setState(() => _showAdCard = false),
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.5),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.close,
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),

          SizedBox(
            height: 70,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: categories.length,
              itemBuilder: (ctx, i) {
                final category = categories[i];
                final isSelected = category == selectedCategory;
                return AnimatedContainer(
                  duration: Duration(milliseconds: 300),
                  margin: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 12,
                  ),
                  child: GestureDetector(
                    onTap: () => setState(() => selectedCategory = category),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 10,
                      ),
                      decoration: BoxDecoration(
                        gradient: isSelected
                            ? LinearGradient(
                          colors: [cs.primary, cs.secondary],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        )
                            : LinearGradient(
                          colors: [
                            cs.surface.withOpacity(0.7),
                            cs.surfaceVariant.withOpacity(0.5),
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        boxShadow: [
                          if (isSelected)
                            BoxShadow(
                              color: cs.primary.withOpacity(0.18),
                              blurRadius: 16,
                              offset: Offset(0, 6),
                            ),
                        ],
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(
                          color: isSelected
                              ? cs.primary.withOpacity(0.7)
                              : cs.onSurface.withOpacity(0.1),
                          width: 2,
                        ),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            _categoryIcon(category),
                            color: isSelected ? Colors.white : cs.primary,
                            size: 22,
                          ),
                          SizedBox(width: 8),
                          Text(
                            category,
                            style: tt.titleMedium?.copyWith(
                              color: isSelected ? Colors.white : cs.primary,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.1,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: currentSongs.length,
              padding: const EdgeInsets.symmetric(vertical: 4),
              itemBuilder: (ctx, i) {
                final song = currentSongs[i];
                return GlassCard(
                  borderRadius: 14,
                  blur: 8,
                  margin: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 6,
                  ),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(14),
                    onTap: () async {
                      final result = await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => SongDetailPage(
                            song: song,
                            hasSubscription: false,
                          ),
                        ),
                      );
                      if (result is Map && result['filePath'] != null) {
                        Navigator.pop(context, result);
                      } else if (result is ShopSong) {
                        Navigator.pop(context, result);
                      }
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 6,
                      ),
                      child: Row(
                        children: [
                          // Album Art
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: song.imagePath.startsWith('assets/')
                                ? Image.asset(
                              song.imagePath,
                              width: 44,
                              height: 44,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Container(
                                width: 44,
                                height: 44,
                                color: cs.onSurface.withOpacity(
                                  0.1,
                                ),
                                child: Icon(
                                  Icons.music_note,
                                  color: cs.primary,
                                ),
                              ),
                            )
                                : Image.network(
                              song.imagePath,
                              width: 44,
                              height: 44,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Container(
                                width: 44,
                                height: 44,
                                color: cs.onSurface.withOpacity(
                                  0.1,
                                ),
                                child: Icon(
                                  Icons.music_note,
                                  color: cs.primary,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          // Song Info
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  song.title,
                                  style: tt.titleMedium?.copyWith(
                                    fontWeight: FontWeight.bold,
                                    color: cs.onSurface,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  song.artist,
                                  style: tt.bodySmall?.copyWith(
                                    color: cs.onSurface.withOpacity(0.7),
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(height: 2),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.star,
                                      size: 14,
                                      color: cs.secondary,
                                    ),
                                    Text(
                                      ' ${song.rating.toStringAsFixed(1)}',
                                      style: tt.bodySmall?.copyWith(
                                        color: cs.onSurface.withOpacity(0.7),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Icon(
                                      Icons.download,
                                      size: 14,
                                      color: cs.onSurface.withOpacity(0.7),
                                    ),
                                    Text(
                                      ' ${song.downloads}',
                                      style: tt.bodySmall?.copyWith(
                                        color: cs.onSurface.withOpacity(0.7),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          // Price or Free
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              (song.isFree || _isPremium)
                                  ? Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.green,
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                child: const Text(
                                  'FREE',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 12,
                                  ),
                                ),
                              )
                                  : Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [cs.primary, cs.secondary],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                child: Text(
                                  '\$${song.price.toStringAsFixed(2)}',
                                  style: tt.bodySmall?.copyWith(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  IconData _categoryIcon(String category) {
    switch (category) {
      case 'Iranian':
        return Icons.flag;
      case 'Foreigner':
        return Icons.language;
      case 'Top of songs':
        return Icons.trending_up;
      case 'The latest':
        return Icons.fiber_new;
      case 'Local Assets':
      // return Icons.folder_music; // این خط مشکل دارد
        return Icons.library_music; // جایگزین مناسب و بدون خطا
      default:
        return Icons.music_note;
    }
  }
}

// GlassCard ویجت شیشه‌ای برای افکت س  ‌بعدی و بلور
class GlassCard extends StatelessWidget {
  final Widget child;
  final double borderRadius;
  final double blur;
  final EdgeInsetsGeometry? margin;
  final Gradient? gradient;

  const GlassCard({
    required this.child,
    this.borderRadius = 20,
    this.blur = 10,
    this.margin,
    this.gradient,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      margin: margin ?? EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(borderRadius),
        gradient: gradient ??
            LinearGradient(
              colors: [
                cs.surface.withOpacity(0.65),
                cs.surfaceVariant.withOpacity(0.45),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
        boxShadow: [
          BoxShadow(
            color: cs.primary.withOpacity(0.10),
            blurRadius: 18,
            offset: Offset(0, 8),
          ),
        ],
        border: Border.all(color: cs.primary.withOpacity(0.10), width: 1.2),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(borderRadius),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
          child: child,
        ),
      ),
    );
  }
}

class SongDetailPage extends StatefulWidget {
  final ShopSong song;
  final bool hasSubscription;

  const SongDetailPage({
    Key? key,
    required this.song,
    required this.hasSubscription,
  }) : super(key: key);

  @override
  State<SongDetailPage> createState() => _SongDetailPageState();
}

class _SongDetailPageState extends State<SongDetailPage> {
  double userRating = 0;
  bool isDownloading = false;
  double downloadProgress = 0;
  List<Comment> comments = [];
  TextEditingController commentController = TextEditingController();
  bool isPurchased = false;
  bool _isPremium = false;

  // اضافه: کنترل وضعیت مرتب‌سازی بر اساس لایک
  bool sortByLikes = false;

  @override
  void initState() {
    super.initState();
    _loadPremiumStatus();
    _loadComments();
  }

  @override
  void dispose() {
    commentController.dispose();
    super.dispose();
  }

  Future<void> _loadPremiumStatus() async {
    final prefs = await SharedPreferences.getInstance();
    final subscription = prefs.getString('subscription') ?? 'STANDARD';
    setState(() {
      _isPremium = subscription.startsWith('PREMIUM');
    });
  }

  void _loadComments() {
    setState(() {
      comments = [
        Comment(
          id: '1',
          username: 'User1',
          text: 'Great song!',
          date: DateTime.now().subtract(const Duration(days: 2)),
          likes: 5,
          dislikes: 1,
        ),
        Comment(
          id: '2',
          username: 'User2',
          text: 'I love this artist',
          date: DateTime.now().subtract(const Duration(days: 1)),
          likes: 3,
          dislikes: 0,
        ),
      ];
    });
  }

  void _submitComment() {
    if (commentController.text.isNotEmpty) {
      setState(() {
        comments.insert(
          0,
          Comment(
            id: DateTime.now().millisecondsSinceEpoch.toString(),
            username: 'CurrentUser',
            text: commentController.text,
            date: DateTime.now(),
          ),
        );
        commentController.clear();
      });
    }
  }

  void _likeComment(String commentId) {
    setState(() {
      final comment = comments.firstWhere((c) => c.id == commentId);
      comment.likes++;
      // setState will rebuild and if sortByLikes is true the list will be shown resorted
    });
  }

  void _dislikeComment(String commentId) {
    setState(() {
      final comment = comments.firstWhere((c) => c.id == commentId);
      comment.dislikes++;
    });
  }

  // helper to get comments in display order
  List<Comment> get displayedComments {
    final copy = List<Comment>.from(comments);
    if (sortByLikes) {
      copy.sort((a, b) => b.likes.compareTo(a.likes));
    }
    return copy;
  }

  Future<String?> _copyAssetToDownloads(String assetPath, String fileName) async {
    try {
      final byteData = await rootBundle.load(assetPath);
      Directory? musicDir;
      if (Platform.isAndroid) {
        // فولدر Music عمومی
        musicDir = Directory('/storage/emulated/0/Music');
        if (!await musicDir.exists()) {
          await musicDir.create(recursive: true);
        }
      } else {
        // برای iOS یا fallback
        final appDocDir = await getApplicationDocumentsDirectory();
        musicDir = Directory('${appDocDir.path}/DownloadedMusic');
        if (!await musicDir.exists()) {
          await musicDir.create(recursive: true);
        }
      }
      final audioFile = File('${musicDir.path}/$fileName');
      await audioFile.writeAsBytes(byteData.buffer.asUint8List());
      return audioFile.path;
    } catch (e) {
      print('Error copying files: $e');
      return null;
    }
  }

  Future<void> _startDownload() async {
    setState(() {
      isDownloading = true;
      downloadProgress = 0;
    });

    String? assetPath;
    String? fileName;

    // اگر آهنگ از Local Assets باشد
    if (widget.song.id.startsWith('asset_')) {
      // فرض: نام فایل همان title با فرمت mp3 است و در assets/audio قرار دارد
      // اگر نام فایل دقیق‌تر نیاز بود، باید در ShopSong ذخیره شود
      final safeTitle = widget.song.title.replaceAll(' ', '_');
      // جستجو در AssetManifest برای پیدا کردن فایل صحیح
      try {
        final manifestContent = await rootBundle.loadString('AssetManifest.json');
        final Map<String, dynamic> manifestMap = json.decode(manifestContent);
        final audioFiles = manifestMap.keys
            .where((String key) =>
        key.startsWith('assets/audio/') && key.endsWith('.mp3'))
            .toList();
        // پیدا کردن فایلی که نامش با title آهنگ یکی باشد (بدون پسوند)
        final found = audioFiles.firstWhere(
                (f) =>
            f.split('/').last.replaceAll('.mp3', '').replaceAll('_', ' ').toLowerCase() ==
                widget.song.title.toLowerCase(),
            orElse: () => '');
        if (found.isNotEmpty) {
          assetPath = found;
          fileName = found.split('/').last;
        }
      } catch (e) {
        print('Error finding asset file: $e');
      }
    } else if (widget.song.id == '3') {
      assetPath = 'assets/audio/Shadmehr Aghili - Bi Ehsas.mp3';
      fileName = 'Shadmehr Aghili - Bi Ehsas.mp3';
    } else if (widget.song.id == '5') {
      assetPath = 'assets/audio/1. NF - CLOUDS (320).mp3';
      fileName = 'NF - CLOUDS.mp3';
    } else if (widget.song.id == '2') {
      assetPath = 'assets/audio/Mehdi Ahmadvand - Divar (1).mp3';
      fileName = 'Mehdi Ahmadvand - Divar (1).mp3';
    }

    if (assetPath != null && fileName != null) {
      for (int i = 0; i <= 100; i += 2) {
        if (!mounted) return;
        setState(() {
          downloadProgress = i / 100;
        });
        await Future.delayed(const Duration(milliseconds: 10));
      }

      final savedPath = await _copyAssetToDownloads(assetPath, fileName);

      setState(() {
        isDownloading = false;
      });

      if (savedPath != null) {
        if (mounted) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text('Download completed!')));
        }
        // Navigator.pop(context, {...});
      }
    } else {
      setState(() {
        isDownloading = false;
      });
      Navigator.pop(context, widget.song);
    }
  }

  void _purchaseSong() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => PaymentPage(amount: widget.song.price)),
    );
    if (result == true) {
      setState(() {
        isPurchased = true;
      });
      // بعد از خرید، دانلود و کپی آهنگ asset
      _startDownload();
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    final tt = theme.textTheme;

    final isFreeForUser =
        widget.song.isFree || _isPremium || widget.hasSubscription || isPurchased;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.song.title, style: tt.titleLarge),
        backgroundColor: cs.surface,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: widget.song.imagePath.startsWith('assets/')
                    ? Image.asset(
                  widget.song.imagePath,
                  width: 200,
                  height: 200,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => Container(
                    width: 200,
                    height: 200,
                    color: cs.onSurface.withOpacity(0.1),
                    child: Icon(
                      Icons.music_note,
                      size: 60,
                      color: cs.primary,
                    ),
                  ),
                )
                    : Image.network(
                  widget.song.imagePath,
                  width: 200,
                  height: 200,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => Container(
                    width: 200,
                    height: 200,
                    color: cs.onSurface.withOpacity(0.1),
                    child: Icon(
                      Icons.music_note,
                      size: 60,
                      color: cs.primary,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Center(
              child: Text(
                widget.song.title,
                style: tt.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: cs.primary,
                ),
              ),
            ),
            Center(
              child: Text(
                widget.song.artist,
                style: tt.bodyMedium?.copyWith(
                  color: cs.onSurface.withOpacity(0.7),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('Rating: ${widget.song.rating}', style: tt.bodyMedium),
                const SizedBox(width: 10),
                ...List.generate(5, (index) {
                  return IconButton(
                    icon: Icon(
                      index < userRating ? Icons.star : Icons.star_border,
                      color: cs.secondary,
                    ),
                    onPressed: () {
                      setState(() {
                        userRating = index + 1.0;
                      });
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            'Rated ${widget.song.title} with $userRating stars',
                            style: tt.bodyMedium,
                          ),
                          backgroundColor: cs.primary,
                        ),
                      );
                    },
                  );
                }),
              ],
            ),
            const SizedBox(height: 20),
            if (isDownloading) ...[
              LinearProgressIndicator(value: downloadProgress),
              Text(
                '${(downloadProgress * 100).toStringAsFixed(0)}%',
                style: tt.bodyMedium,
              ),
            ] else if (isFreeForUser)
              Center(
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: cs.primary,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 32,
                      vertical: 12,
                    ),
                  ),
                  onPressed: _startDownload,
                  child: Text(
                    'Download Now',
                    style: tt.bodyLarge?.copyWith(color: cs.onPrimary),
                  ),
                ),
              )
            else
              Center(
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: cs.primary,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 32,
                      vertical: 12,
                    ),
                  ),
                  onPressed: _purchaseSong,
                  child: Text(
                    'Purchase for \$${widget.song.price}',
                    style: tt.bodyLarge?.copyWith(color: cs.onPrimary),
                  ),
                ),
              ),
            const SizedBox(height: 30),
            Text(
              'Details',
              style: tt.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
                color: cs.primary,
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Icon(
                  Icons.download,
                  size: 16,
                  color: cs.onSurface.withOpacity(0.7),
                ),
                const SizedBox(width: 8),
                Text(
                  'Downloads: ${widget.song.downloads}',
                  style: tt.bodyMedium,
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(
                  Icons.attach_money,
                  size: 16,
                  color: cs.onSurface.withOpacity(0.7),
                ),
                const SizedBox(width: 8),
                Text('Price: \$${widget.song.price}', style: tt.bodyMedium),
              ],
            ),
            const SizedBox(height: 30),
            Text(
              'Comments',
              style: tt.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
                color: cs.primary,
              ),
            ),
            const SizedBox(height: 10),

            // ورودی کامنت + دکمه ارسال + دکمه مرتب‌سازی
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: commentController,
                    style: tt.bodyMedium?.copyWith(color: cs.onSurface),
                    decoration: InputDecoration(
                      hintText: 'Add your comment...',
                      hintStyle: tt.bodySmall?.copyWith(
                        color: cs.onSurface.withOpacity(0.7),
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide(color: cs.primary),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide(color: cs.primary),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide(color: cs.primary),
                      ),
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send, color: cs.primary),
                  onPressed: _submitComment,
                ),
                const SizedBox(width: 8),
                // دکمه مرتب‌سازی بر اساس لایک
                IconButton(
                  icon: Icon(
                    Icons.sort,
                    color: sortByLikes ? cs.secondary : cs.onSurface.withOpacity(0.6),
                  ),
                  tooltip: sortByLikes ? 'Sorted by likes' : 'Sort by likes',
                  onPressed: () {
                    setState(() {
                      sortByLikes = !sortByLikes;
                    });
                  },
                ),
              ],
            ),
            const SizedBox(height: 20),

            // نمایش کامنت‌ها (با توجه به حالت مرتب‌سازی)
            ...displayedComments.map(
                  (comment) => Card(
                margin: const EdgeInsets.only(bottom: 10),
                color: cs.surface,
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            comment.username,
                            style: tt.bodyMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                              color: cs.primary,
                            ),
                          ),
                          Text(
                            '${comment.date.day}/${comment.date.month}/${comment.date.year}',
                            style: tt.bodySmall?.copyWith(
                              color: cs.onSurface.withOpacity(0.7),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(comment.text, style: tt.bodyMedium),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          IconButton(
                            icon: Icon(
                              Icons.thumb_up,
                              size: 16,
                              color: cs.secondary,
                            ),
                            onPressed: () => _likeComment(comment.id),
                          ),
                          Text(comment.likes.toString(), style: tt.bodyMedium),
                          const SizedBox(width: 8),
                          IconButton(
                            icon: Icon(
                              Icons.thumb_down,
                              size: 16,
                              color: cs.onSurface.withOpacity(0.7),
                            ),
                            onPressed: () => _dislikeComment(comment.id),
                          ),
                          Text(
                            comment.dislikes.toString(),
                            style: tt.bodyMedium,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

