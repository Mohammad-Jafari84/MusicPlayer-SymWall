package com.example.symwall

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
